package com.BankingApplication.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.BankingApplication.entity.Amount;

public interface AmountRepository extends JpaRepository<Amount, String> {
	@Query("from Amount where toAccount=:toAccount and amount=:amount and balance=:balance")
	List<Amount> findAmount(@Param("toAccount")String to,@Param("amount")String amount,@Param("balance")String balance);


}
