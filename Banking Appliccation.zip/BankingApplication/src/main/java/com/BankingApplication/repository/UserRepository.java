package com.BankingApplication.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.BankingApplication.entity.Users;

public interface UserRepository extends JpaRepository<Users, String> {

	Users findById(Long userId);

}
