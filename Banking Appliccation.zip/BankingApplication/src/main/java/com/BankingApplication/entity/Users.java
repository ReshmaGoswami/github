package com.BankingApplication.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Users{
	@Id
private String UserId;
private String firstName;
private String lastName;
private String CreatedAt;
private String UpdatedAt;
private String password;
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getCreatedAt() {
	return CreatedAt;
}
public void setCreatedAt(String createdAt) {
	CreatedAt = createdAt;
}
public String getUpdatedAt() {
	return UpdatedAt;
}
public void setUpdatedAt(String updatedAt) {
	UpdatedAt = updatedAt;
}
public String getUserId() {
	return UserId;
}
public void setUserId(String userId) {
	UserId = userId;
}
}

