package com.BankingApplication.entity;

import javax.persistence.Entity;

@Entity
public class Amount {
private String Balance;
private String	Userid;
public String getUserid() {
	return Userid;
}
public void setUserid(String userid) {
	Userid = userid;
}
public String getBalance_amount() {
	return balance_amount;
}
public void setBalance_amount(String balance_amount) {
	this.balance_amount = balance_amount;
}
public String getCreated_at() {
	return created_at;
}
public void setCreated_at(String created_at) {
	this.created_at = created_at;
}
public String getUpdated_at() {
	return Updated_at;
}
public void setUpdated_at(String updated_at) {
	Updated_at = updated_at;
}
public String getBalance() {
	return Balance;
}
public void setBalance(String balance) {
	Balance = balance;
}
private String balance_amount;
private String	created_at;
private String	Updated_at;

}
