package com.BankingApplication.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.BankingApplication.entity.Amount;
import com.BankingApplication.repository.AmountRepository;

@Controller
public class AmountController {
	@Autowired 
	private AmountRepository amountRepo;
	@RequestMapping("/SendTo")
 public String findAmount(@RequestParam("userId")Long userId,@RequestParam("to")String to,@RequestParam("amount")String amount,@RequestParam("balance") String Balance ,ModelMap modelMap){
		List<Amount> findAmount = amountRepo.findAmount(to, amount,Balance);
			modelMap.addAttribute("findAmount",findAmount); 
		return "displayDetails";
		}
	@RequestMapping("/showCompleteDetails")
	public String showCompleteDetails(@RequestParam("UserId")String UserId,ModelMap modelMap) {
	Optional<Amount> findById = amountRepo.findById(UserId);
		  Amount amount = findById.get();
		modelMap.addAttribute("amount",amount);
		return "showConfirmation";
	}
}


