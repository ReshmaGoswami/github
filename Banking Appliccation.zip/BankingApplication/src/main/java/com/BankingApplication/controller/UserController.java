package com.BankingApplication.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.BankingApplication.entity.Users;
import com.BankingApplication.repository.UserRepository;

@Controller
public class UserController {
	@Autowired
	private UserRepository userRepo;
	@RequestMapping("/showLoginPage")
	public String showLoginPage() {
		return "login/login";
	}
	@RequestMapping("/showReg")
public String showReg() {
	return "login/showReg";
}
	@RequestMapping("/saveReg")
	public String saveReg(@ModelAttribute("users")Users users){
		userRepo.save(users);
		return "login/login";
	}
	@RequestMapping("/verifyLogin")
	public String verifyLogin(@RequestParam("userId")Long userId,@RequestParam("password")String password,ModelMap modelMap) {
	Users users =userRepo.findById(userId);
	
		if(users!=null) {
		if(users.getUserId().equals(userId) && users.getPassword().equals(password)) {
			return "login/SendToContact";
		}else {
			modelMap.addAttribute("error","invlid username/password");
			return "login/login";
		}
		}else {
			modelMap.addAttribute("error","invlid username/password");
			return "login/login";
		}
			
	}

}
